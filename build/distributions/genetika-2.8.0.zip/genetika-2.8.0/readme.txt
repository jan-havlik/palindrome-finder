Config
======

Two sample config files are attached. Select one of config.properties.* files and rename it to config.properties.

For server mode
---------------

This mode allows multiple user accounts.

- select config.properties.server
- set desired network port
- set correct SMTP server parameters (for password resets)

For desktop mode
----------------
- select config.properties.desktop